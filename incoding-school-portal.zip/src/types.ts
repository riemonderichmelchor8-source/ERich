export interface StudentProfile {
  name: string;
  studentId: string;
  email: string;
  avatar: string;
  cohort: string;
  track: string;
  bio: string;
  streakDays: number;
  totalPoints: number;
  level: number;
  xpCurrent: number;
  xpNextLevel: number;
  badges: Badge[];
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlockedAt?: string;
  isUnlocked: boolean;
}

export interface TestCase {
  name: string;
  passed: boolean;
  details: string;
}

export interface AssignmentSubmission {
  code: string;
  notes?: string;
  fileName?: string;
  submittedAt: string;
  score?: number;
  gradeLetter?: string;
  status: "passed" | "needs_revision" | "grading";
  summary?: string;
  testCases?: TestCase[];
  strengths?: string[];
  areasForImprovement?: string[];
  codeSuggestions?: string;
}

export interface Assignment {
  id: string;
  title: string;
  track: string;
  moduleName: string;
  dueDate: string;
  points: number;
  difficulty: "Beginner" | "Intermediate" | "Advanced";
  description: string;
  instructions: string[];
  starterCode: string;
  rubric: { criterion: string; weight: string }[];
  status: "pending" | "submitted" | "graded";
  submission?: AssignmentSubmission;
}

export interface OnboardingTask {
  id: string;
  title: string;
  category: "Setup" | "Community" | "Academic" | "Career";
  completed: boolean;
  points: number;
  estimatedTime: string;
  description: string;
}

export interface ForumReply {
  id: string;
  authorName: string;
  authorAvatar: string;
  authorRole: "Student" | "TA" | "Instructor";
  content: string;
  codeSnippet?: string;
  createdAt: string;
  upvotes: number;
  isSolution?: boolean;
  userUpvoted?: boolean;
}

export interface ForumPost {
  id: string;
  authorName: string;
  authorAvatar: string;
  authorRole: "Student" | "TA" | "Instructor";
  title: string;
  category: "General" | "Homework Help" | "Show & Tell" | "Meetup" | "Career";
  tags: string[];
  content: string;
  codeSnippet?: string;
  createdAt: string;
  upvotes: number;
  views: number;
  isSolved: boolean;
  userUpvoted?: boolean;
  replies: ForumReply[];
}

export interface ActivityNotification {
  id: string;
  type: "submission" | "forum" | "announcement" | "achievement";
  text: string;
  timestamp: string;
  read: boolean;
  linkTab?: string;
}

export interface CohortMember {
  id: string;
  name: string;
  avatar: string;
  track: string;
  status: "online" | "coding" | "offline";
  progress: number;
  currentBadge: string;
}
