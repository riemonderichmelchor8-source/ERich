import React, { useState, useEffect } from "react";
import { Navbar } from "./components/Navbar";
import { LiveTickerBar } from "./components/LiveTickerBar";
import { DashboardView } from "./components/DashboardView";
import { AssignmentsView } from "./components/AssignmentsView";
import { ForumView } from "./components/ForumView";
import { AITutorView } from "./components/AITutorView";
import { ProfileView } from "./components/ProfileView";

import { 
  StudentProfile, 
  Assignment, 
  OnboardingTask, 
  ForumPost, 
  ActivityNotification, 
  CohortMember 
} from "./types";

import { 
  initialStudentProfile, 
  initialAssignments, 
  initialOnboardingTasks, 
  initialForumPosts, 
  initialNotifications, 
  initialCohortMembers 
} from "./data/mockData";

import { Sparkles, Award } from "lucide-react";

export default function App() {
  const [activeTab, setActiveTab] = useState<string>("dashboard");

  // LocalStorage state initialization
  const [profile, setProfile] = useState<StudentProfile>(() => {
    const saved = localStorage.getItem("incoding_profile");
    return saved ? JSON.parse(saved) : initialStudentProfile;
  });

  const [assignments, setAssignments] = useState<Assignment[]>(() => {
    const saved = localStorage.getItem("incoding_assignments");
    return saved ? JSON.parse(saved) : initialAssignments;
  });

  const [onboardingTasks, setOnboardingTasks] = useState<OnboardingTask[]>(() => {
    const saved = localStorage.getItem("incoding_tasks");
    return saved ? JSON.parse(saved) : initialOnboardingTasks;
  });

  const [forumPosts, setForumPosts] = useState<ForumPost[]>(() => {
    const saved = localStorage.getItem("incoding_forum");
    return saved ? JSON.parse(saved) : initialForumPosts;
  });

  const [notifications, setNotifications] = useState<ActivityNotification[]>(initialNotifications);
  const [cohortMembers] = useState<CohortMember[]>(initialCohortMembers);
  const [selectedAssignmentId, setSelectedAssignmentId] = useState<string>(initialAssignments[0].id);

  // Toast Banner State
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Save states to localStorage
  useEffect(() => {
    localStorage.setItem("incoding_profile", JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem("incoding_assignments", JSON.stringify(assignments));
  }, [assignments]);

  useEffect(() => {
    localStorage.setItem("incoding_tasks", JSON.stringify(onboardingTasks));
  }, [onboardingTasks]);

  useEffect(() => {
    localStorage.setItem("incoding_forum", JSON.stringify(forumPosts));
  }, [forumPosts]);

  // Handle XP Earned Trigger
  const handleXPEarned = (points: number, sourceName: string) => {
    setProfile((prev) => {
      const newTotal = prev.totalPoints + points;
      const newXp = prev.xpCurrent + points;
      let newLevel = prev.level;
      let newNextLevel = prev.xpNextLevel;

      if (newXp >= newNextLevel) {
        newLevel += 1;
        newNextLevel += 300;
      }

      return {
        ...prev,
        totalPoints: newTotal,
        xpCurrent: newXp,
        level: newLevel,
        xpNextLevel: newNextLevel
      };
    });

    setToastMessage(`🎉 Earned +${points} XP from ${sourceName}!`);
    setTimeout(() => setToastMessage(null), 4000);

    // Add Notification
    setNotifications((prev) => [
      {
        id: "notif-" + Date.now(),
        type: "achievement",
        text: `You earned +${points} XP for submitting '${sourceName}'.`,
        timestamp: "Just now",
        read: false,
        linkTab: "dashboard"
      },
      ...prev
    ]);
  };

  const handleAssignmentSubmitted = (pointsEarned: number) => {
    handleXPEarned(pointsEarned, "Assignment Submission");
  };

  const handleForumTopicCreated = () => {
    handleXPEarned(25, "Forum Discussion Post");
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-indigo-600 selection:text-white flex flex-col">
      
      {/* Toast Banner Alert */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 bg-gradient-to-r from-indigo-600 to-cyan-600 text-white font-extrabold text-xs px-5 py-3 rounded-2xl shadow-2xl border border-indigo-400/50 flex items-center gap-2.5 animate-bounce">
          <Sparkles className="w-4 h-4 text-amber-300" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Portal Top Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        profile={profile}
        notifications={notifications}
        setNotifications={setNotifications}
        onlineCount={48}
      />

      {/* Live Stream Events Ticker */}
      <LiveTickerBar />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {activeTab === "dashboard" && (
          <DashboardView
            profile={profile}
            assignments={assignments}
            onboardingTasks={onboardingTasks}
            setOnboardingTasks={setOnboardingTasks}
            setActiveTab={setActiveTab}
            setSelectedAssignmentId={setSelectedAssignmentId}
          />
        )}

        {activeTab === "assignments" && (
          <AssignmentsView
            assignments={assignments}
            setAssignments={setAssignments}
            selectedAssignmentId={selectedAssignmentId}
            setSelectedAssignmentId={setSelectedAssignmentId}
            onSubmissionSuccess={handleAssignmentSubmitted}
          />
        )}

        {activeTab === "forum" && (
          <ForumView
            posts={forumPosts}
            setPosts={setForumPosts}
            onPostCreated={handleForumTopicCreated}
          />
        )}

        {activeTab === "ai-tutor" && <AITutorView />}

        {activeTab === "profile" && (
          <ProfileView
            profile={profile}
            setProfile={setProfile}
            cohortMembers={cohortMembers}
            assignments={assignments}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p>© 2026 InCoding Academy • Incoming Student Portal (Fall Cohort)</p>
          <div className="flex items-center gap-4 text-[11px] text-slate-400">
            <span>24/7 AI TA Connected</span>
            <span>•</span>
            <span>Automated Code Rubric Engine</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
