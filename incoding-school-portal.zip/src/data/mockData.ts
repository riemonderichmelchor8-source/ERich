import { StudentProfile, Assignment, OnboardingTask, ForumPost, ActivityNotification, CohortMember } from "../types";

export const initialStudentProfile: StudentProfile = {
  name: "Jordan Rivera",
  studentId: "INC-2026-8841",
  email: "jordan.r@incoding.edu",
  avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250",
  cohort: "Fall 2026 Incoming Cohort",
  track: "Full-Stack Software Engineering",
  bio: "Passionate incoming student interested in React, TypeScript, AI APIs, and backend system architecture.",
  streakDays: 5,
  totalPoints: 420,
  level: 3,
  xpCurrent: 420,
  xpNextLevel: 600,
  badges: [
    {
      id: "b1",
      name: "Early Bird",
      description: "Completed student profile before orientation day",
      icon: "⚡",
      isUnlocked: true,
      unlockedAt: "2 days ago"
    },
    {
      id: "b2",
      name: "Hello World",
      description: "Submitted first verified code assignment",
      icon: "🚀",
      isUnlocked: true,
      unlockedAt: "Yesterday"
    },
    {
      id: "b3",
      name: "Forum Helper",
      description: "Answered a classmate's question in the discussion forum",
      icon: "💬",
      isUnlocked: true,
      unlockedAt: "Today"
    },
    {
      id: "b4",
      name: "Bug Hunter",
      description: "Passed all edge cases on an advanced assignment test suite",
      icon: "🐞",
      isUnlocked: false
    },
    {
      id: "b5",
      name: "Continuous Code",
      description: "Maintain a 7-day active coding streak",
      icon: "🔥",
      isUnlocked: false
    }
  ]
};

export const initialAssignments: Assignment[] = [
  {
    id: "assign-101",
    title: "Orientation: Development Setup & Hello World",
    track: "Core Computer Science",
    moduleName: "Module 1: Environment & Tooling",
    dueDate: "Tomorrow, 11:59 PM",
    points: 100,
    difficulty: "Beginner",
    description: "Set up your Node.js & TypeScript environment, create a CLI utility that formats student onboarding profiles, and verify environment runtime.",
    instructions: [
      "Define a function `createStudentProfile(name: string, track: string)` that returns a formatted JSON object.",
      "Calculate the current onboarding completion percentage based on completed module tasks.",
      "Print a clean banner welcome message to stdout."
    ],
    starterCode: `/**
 * InCoding Orientation Task 1
 * Implement student profile generator function
 */

export interface StudentData {
  id: string;
  name: string;
  track: string;
  isReady: boolean;
  completionScore: number;
}

export function createStudentProfile(name: string, track: string): StudentData {
  // TODO: Implement profile generation logic
  return {
    id: "INC-" + Math.floor(1000 + Math.random() * 9000),
    name: name,
    track: track,
    isReady: true,
    completionScore: 100
  };
}

// Test call
console.log(createStudentProfile("Jordan Rivera", "Full-Stack Development"));
`,
    rubric: [
      { criterion: "TypeScript Type Definitions", weight: "25%" },
      { criterion: "Correct Function Logic & Return Object", weight: "50%" },
      { criterion: "Code Style & Error Handling", weight: "25%" }
    ],
    status: "graded",
    submission: {
      code: `export function createStudentProfile(name: string, track: string) {
  return {
    id: "INC-2026-8841",
    name: name.trim(),
    track: track,
    isReady: true,
    completionScore: 100
  };
}`,
      notes: "Completed environment setup on Node 22 and verified TypeScript compiler.",
      fileName: "solution_orientation.ts",
      submittedAt: "2026-07-23 14:32",
      score: 98,
      gradeLetter: "A+",
      status: "passed",
      summary: "Excellent work! Clean typing and proper formatting.",
      testCases: [
        { name: "Exports valid function", passed: true, details: "Function createStudentProfile exists and can be invoked." },
        { name: "Valid ID format", passed: true, details: "ID follows INC prefix standard." },
        { name: "String sanitization", passed: true, details: "Trims whitespace correctly." }
      ],
      strengths: ["Clean export syntax", "Correct type returns", "Trims whitespace"],
      areasForImprovement: ["Add explicit parameter type annotations for strict mode."]
    }
  },
  {
    id: "assign-102",
    title: "Data Structures: Array & Object Manipulation",
    track: "Core Computer Science",
    moduleName: "Module 2: Algorithms Foundations",
    dueDate: "In 3 Days",
    points: 150,
    difficulty: "Intermediate",
    description: "Write a high-performance filtering and sorting utility that computes cohort statistics from an array of incoming student records.",
    instructions: [
      "Implement `calculateCohortStats(students)` to return average completion %, top track, and active student list.",
      "Filter out inactive or dropped enrollment records safely.",
      "Ensure O(N) runtime complexity using single-pass iteration or efficient map/reduce."
    ],
    starterCode: `/**
 * Module 2: Cohort Statistics Calculator
 */

export interface StudentRecord {
  name: string;
  track: string;
  score: number;
  active: boolean;
}

export function calculateCohortStats(students: StudentRecord[]) {
  // TODO: Calculate average score of ACTIVE students
  // TODO: Find highest performing track
  
  return {
    activeCount: 0,
    averageScore: 0,
    topTrack: ""
  };
}
`,
    rubric: [
      { criterion: "Data Integrity & Filtering", weight: "30%" },
      { criterion: "Algorithm Efficiency (O(N))", weight: "40%" },
      { criterion: "Edge Case Safety (Empty array, all inactive)", weight: "30%" }
    ],
    status: "pending"
  },
  {
    id: "assign-103",
    title: "Async Operations & REST API Client",
    track: "Full-Stack Development",
    moduleName: "Module 3: Asynchronous JavaScript & Fetch",
    dueDate: "In 5 Days",
    points: 200,
    difficulty: "Intermediate",
    description: "Build an async client function with automatic retry logic, delay backoff, and robust error handling to fetch course curriculum data.",
    instructions: [
      "Implement `fetchCurriculumWithRetry(url: string, retries: number)` using async/await.",
      "Handle network timeouts and 5xx server status codes gracefully.",
      "Return parsed JSON response or thrown custom Error."
    ],
    starterCode: `/**
 * Module 3: Robust Async Fetch Client
 */

export async function fetchCurriculumWithRetry(url: string, maxRetries = 3): Promise<any> {
  // TODO: Implement exponential backoff retry fetch
  throw new Error("Not implemented yet");
}
`,
    rubric: [
      { criterion: "Async/Await & Error Handling", weight: "40%" },
      { criterion: "Retry Backoff Algorithm", weight: "35%" },
      { criterion: "Promise Type Safety", weight: "25%" }
    ],
    status: "pending"
  },
  {
    id: "assign-104",
    title: "React Component Architecture: Interactive Quiz",
    track: "Frontend Engineering",
    moduleName: "Module 4: UI Frameworks",
    dueDate: "In 1 Week",
    points: 250,
    difficulty: "Advanced",
    description: "Create a modular, accessible React component for incoming students to practice coding quizzes with score persistence and feedback.",
    instructions: [
      "Build `QuizCard` and `ScoreSummary` components with custom hooks.",
      "Manage step progression state cleanly.",
      "Add interactive progress indicators and immediate answer feedback."
    ],
    starterCode: `import React, { useState } from 'react';

export function QuizCard({ question, options, onAnswer }: any) {
  // TODO: Component state & event handlers
  return (
    <div className="p-4 border rounded">
      <h3>{question}</h3>
    </div>
  );
}
`,
    rubric: [
      { criterion: "Component Modularity & Clean State", weight: "40%" },
      { criterion: "Accessibility & Styling", weight: "30%" },
      { criterion: "User Interaction & Feedback", weight: "30%" }
    ],
    status: "pending"
  }
];

export const initialOnboardingTasks: OnboardingTask[] = [
  {
    id: "task-1",
    title: "Complete Student Profile & Bio",
    category: "Setup",
    completed: true,
    points: 50,
    estimatedTime: "5 mins",
    description: "Add your picture, avatar, track preference, and short intro for your classmates."
  },
  {
    id: "task-2",
    title: "Connect to Class Slack / Discord Workspace",
    category: "Community",
    completed: true,
    points: 50,
    estimatedTime: "10 mins",
    description: "Join the official #fall-2026 channel to meet cohort peers and TAs."
  },
  {
    id: "task-3",
    title: "Verify Git & GitHub SSH Keys",
    category: "Setup",
    completed: true,
    points: 75,
    estimatedTime: "15 mins",
    description: "Configure local git user.name, user.email and add your SSH public key to GitHub."
  },
  {
    id: "task-4",
    title: "Submit Orientation Homework #1",
    category: "Academic",
    completed: true,
    points: 100,
    estimatedTime: "45 mins",
    description: "Complete and submit solution for 'Orientation: Development Setup'."
  },
  {
    id: "task-5",
    title: "Introduce Yourself in Discussion Forum",
    category: "Community",
    completed: false,
    points: 50,
    estimatedTime: "5 mins",
    description: "Post a quick intro in #incoming-meetup with your coding background & goals."
  },
  {
    id: "task-6",
    title: "Schedule 1-on-1 Mentor Check-in",
    category: "Career",
    completed: false,
    points: 100,
    estimatedTime: "5 mins",
    description: "Pick a time slot with your assigned Senior Software Engineer mentor."
  }
];

export const initialForumPosts: ForumPost[] = [
  {
    id: "post-1",
    authorName: "Sarah Chen",
    authorAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=150",
    authorRole: "Student",
    title: "How to handle optional chaining in TypeScript for nested API objects?",
    category: "Homework Help",
    tags: ["TypeScript", "API", "Syntax"],
    content: "Hey incoming cohort! While working on Assignment 2, I ran into an issue where accessing `student.profile.details` throws an undefined error if profile is null. What is the cleanest pattern here?",
    codeSnippet: `// Failing code:
const city = response.data.student.profile.address.city;

// Is this the best pattern?
const citySafe = response.data?.student?.profile?.address?.city ?? "Unknown";`,
    createdAt: "2 hours ago",
    upvotes: 14,
    views: 89,
    isSolved: true,
    userUpvoted: false,
    replies: [
      {
        id: "rep-101",
        authorName: "Alex Mercer (TA)",
        authorAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=150",
        authorRole: "TA",
        content: "Spot on, Sarah! Optional chaining (`?.`) paired with the nullish coalescing operator (`??`) is indeed the industry standard in TypeScript. It safely returns 'Unknown' if any key along the chain is `null` or `undefined` without throwing runtime crashes.",
        codeSnippet: `// Recommended pattern with type safety:
interface StudentResponse {
  student?: {
    profile?: {
      address?: {
        city?: string;
      };
    };
  };
}

const city = response.data?.student?.profile?.address?.city ?? "Default City";`,
        createdAt: "1 hour ago",
        upvotes: 8,
        isSolution: true,
        userUpvoted: true
      }
    ]
  },
  {
    id: "post-2",
    authorName: "David K.",
    authorAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=150",
    authorRole: "Student",
    title: "👋 Hi everyone! Incoming Full-Stack student from Seattle!",
    category: "Meetup",
    tags: ["Intro", "Networking", "Seattle"],
    content: "Excited to join the InCoding Fall 2026 cohort! I've been learning Python for a few months and am eager to dive deep into TypeScript and React. Looking forward to virtual study sessions and pair programming!",
    createdAt: "5 hours ago",
    upvotes: 22,
    views: 140,
    isSolved: false,
    userUpvoted: true,
    replies: [
      {
        id: "rep-201",
        authorName: "Elena Rostova",
        authorAvatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150",
        authorRole: "Student",
        content: "Welcome David! I'm in Vancouver (Pacific time zone as well). Let's start a Discord study group for the Module 2 assignment!",
        createdAt: "4 hours ago",
        upvotes: 5,
        userUpvoted: false
      }
    ]
  },
  {
    id: "post-3",
    authorName: "Marcus Vance (Instructor)",
    authorAvatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=150",
    authorRole: "Instructor",
    title: "📌 Pro-Tip: Leveraging AI Automated Code Feedback before Final Submissions",
    category: "General",
    tags: ["Tips", "AI-Tutor", "Submissions"],
    content: "Welcome incoming students! Remember that our portal has a built-in AI Evaluator & Tutor. Before submitting your final assignment code, click 'Run AI Evaluation' to get immediate test case breakdowns, code quality tips, and performance suggestions!",
    createdAt: "1 day ago",
    upvotes: 45,
    views: 310,
    isSolved: false,
    userUpvoted: true,
    replies: []
  }
];

export const initialNotifications: ActivityNotification[] = [
  {
    id: "notif-1",
    type: "submission",
    text: "Your submission for 'Orientation Setup' was graded: 98/100 (A+)",
    timestamp: "10m ago",
    read: false,
    linkTab: "assignments"
  },
  {
    id: "notif-2",
    type: "achievement",
    text: "🎉 Unlocked 'Forum Helper' Badge (+50 XP)",
    timestamp: "1h ago",
    read: false,
    linkTab: "profile"
  },
  {
    id: "notif-3",
    type: "forum",
    text: "Alex Mercer (TA) replied to a discussion thread you were following.",
    timestamp: "2h ago",
    read: true,
    linkTab: "forum"
  }
];

export const initialCohortMembers: CohortMember[] = [
  { id: "cm-1", name: "Jordan Rivera", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150", track: "Full-Stack SE", status: "coding", progress: 68, currentBadge: "Hello World" },
  { id: "cm-2", name: "Sarah Chen", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=150", track: "Full-Stack SE", status: "online", progress: 85, currentBadge: "Bug Hunter" },
  { id: "cm-3", name: "David K.", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=150", track: "AI Engineering", status: "online", progress: 52, currentBadge: "Early Bird" },
  { id: "cm-4", name: "Elena Rostova", avatar: "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=150", track: "Frontend Tech", status: "coding", progress: 74, currentBadge: "Hello World" },
  { id: "cm-5", name: "Alex Mercer (TA)", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=150", track: "InCoding Staff", status: "online", progress: 100, currentBadge: "Staff Leader" }
];
