import React, { useState } from "react";
import { 
  BookOpen, 
  CheckCircle2, 
  Clock, 
  Code2, 
  UploadCloud, 
  Sparkles, 
  Send, 
  RotateCcw, 
  FileCode, 
  HelpCircle, 
  Check, 
  X, 
  Award, 
  AlertCircle, 
  FileText,
  Copy,
  Terminal,
  Loader2
} from "lucide-react";
import { Assignment, AssignmentSubmission } from "../types";

interface AssignmentsViewProps {
  assignments: Assignment[];
  setAssignments: React.Dispatch<React.SetStateAction<Assignment[]>>;
  selectedAssignmentId: string;
  setSelectedAssignmentId: (id: string) => void;
  onSubmissionSuccess: (pointsEarned: number) => void;
}

export const AssignmentsView: React.FC<AssignmentsViewProps> = ({
  assignments,
  setAssignments,
  selectedAssignmentId,
  setSelectedAssignmentId,
  onSubmissionSuccess
}) => {
  const activeAssignment = assignments.find((a) => a.id === selectedAssignmentId) || assignments[0];

  const [code, setCode] = useState<string>(activeAssignment?.submission?.code || activeAssignment?.starterCode || "");
  const [notes, setNotes] = useState<string>(activeAssignment?.submission?.notes || "");
  const [uploadedFileName, setUploadedFileName] = useState<string>(activeAssignment?.submission?.fileName || "");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  
  const [isEvaluating, setIsEvaluating] = useState<boolean>(false);
  const [evaluationResult, setEvaluationResult] = useState<AssignmentSubmission | null>(
    activeAssignment?.submission || null
  );
  
  const [hint, setHint] = useState<string>("");
  const [isLoadingHint, setIsLoadingHint] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  // Switch active assignment handler
  const handleSelectAssignment = (assign: Assignment) => {
    setSelectedAssignmentId(assign.id);
    setCode(assign.submission?.code || assign.starterCode || "");
    setNotes(assign.submission?.notes || "");
    setUploadedFileName(assign.submission?.fileName || "");
    setEvaluationResult(assign.submission || null);
    setHint("");
  };

  // Reset code to starter code
  const handleResetCode = () => {
    setCode(activeAssignment.starterCode);
  };

  // Copy code to clipboard
  const handleCopyCode = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Handle Drag & Drop File Upload Simulation
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadedFileName(file.name);
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        if (content) {
          setCode(content);
        }
      };
      reader.readAsText(file);
    }
  };

  // Request Hint from AI API
  const handleFetchHint = async () => {
    setIsLoadingHint(true);
    try {
      const res = await fetch("/api/ai/hint", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          assignmentTitle: activeAssignment.title,
          currentCode: code
        })
      });
      const data = await res.json();
      setHint(data.hint || "Try checking your syntax and variable types.");
    } catch {
      setHint("Check function parameter types and make sure all expected properties are returned.");
    } finally {
      setIsLoadingHint(false);
    }
  };

  // Submit Code & Run AI Evaluation API
  const handleSubmitAndEvaluate = async () => {
    if (!code.trim()) return;

    setIsEvaluating(true);
    setHint("");

    try {
      const res = await fetch("/api/ai/evaluate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          assignmentTitle: activeAssignment.title,
          assignmentDescription: activeAssignment.description,
          studentCode: code,
          submissionNotes: notes
        })
      });

      const data = await res.json();

      const newSubmission: AssignmentSubmission = {
        code,
        notes,
        fileName: uploadedFileName || "solution.ts",
        submittedAt: new Date().toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }),
        score: data.score || 90,
        gradeLetter: data.gradeLetter || "A",
        status: data.status || "passed",
        summary: data.summary || "Submission evaluated successfully.",
        testCases: data.testCases || [],
        strengths: data.strengths || [],
        areasForImprovement: data.areasForImprovement || [],
        codeSuggestions: data.codeSuggestions || ""
      };

      setEvaluationResult(newSubmission);

      // Update state for assignments list
      setAssignments((prev) =>
        prev.map((a) =>
          a.id === activeAssignment.id
            ? { ...a, status: "graded", submission: newSubmission }
            : a
        )
      );

      // Trigger XP reward on completion
      onSubmissionSuccess(activeAssignment.points);

    } catch (err) {
      console.error("Submission evaluation error:", err);
    } finally {
      setIsEvaluating(false);
    }
  };

  const filteredAssignments = assignments.filter((a) => {
    if (filterStatus === "pending") return a.status === "pending";
    if (filterStatus === "submitted") return a.status === "submitted" || a.status === "graded";
    return true;
  });

  return (
    <div className="space-y-8 pb-12">
      
      {/* Header Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 text-xs font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 rounded-full flex items-center gap-1">
              <BookOpen className="w-3.5 h-3.5" /> Assignment Submission Portal
            </span>
          </div>
          <h1 className="text-2xl font-extrabold text-slate-100">Coding Workspace & Evaluation</h1>
          <p className="text-xs text-slate-400">Submit TypeScript/JS code solutions for automated AI test suite execution</p>
        </div>

        {/* Filter Buttons */}
        <div className="flex items-center gap-2 bg-slate-950/80 p-1 rounded-xl border border-slate-800/80 self-start md:self-auto">
          {["all", "pending", "submitted"].map((status) => (
            <button
              key={status}
              onClick={() => setFilterStatus(status)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold capitalize transition ${
                filterStatus === status
                  ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              {status}
            </button>
          ))}
        </div>
      </div>

      {/* Main Split Interface */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Sidebar (4 cols): Assignment Selection List */}
        <div className="lg:col-span-4 space-y-4">
          <h3 className="text-sm font-bold text-slate-300 uppercase tracking-wider px-1">
            Assignment List ({filteredAssignments.length})
          </h3>

          <div className="space-y-3">
            {filteredAssignments.map((assignment) => {
              const isSelected = assignment.id === activeAssignment.id;
              const isGraded = assignment.status === "graded";

              return (
                <div
                  key={assignment.id}
                  onClick={() => handleSelectAssignment(assignment)}
                  className={`p-4 rounded-2xl border transition cursor-pointer relative ${
                    isSelected
                      ? "bg-indigo-950/40 border-indigo-500/80 shadow-lg shadow-indigo-950/50"
                      : "bg-slate-900/80 border-slate-800 hover:border-slate-700"
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="text-[10px] font-bold text-cyan-400 bg-cyan-500/10 border border-cyan-500/20 px-2 py-0.5 rounded">
                      {assignment.track}
                    </span>
                    {isGraded ? (
                      <span className="px-2 py-0.5 text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Graded
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded">
                        Pending
                      </span>
                    )}
                  </div>

                  <h4 className="font-bold text-slate-100 text-sm leading-snug">{assignment.title}</h4>
                  <p className="text-xs text-slate-400 mt-1 line-clamp-2">{assignment.description}</p>

                  <div className="flex items-center justify-between text-[11px] text-slate-500 mt-3 pt-2 border-t border-slate-800/60 font-mono">
                    <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {assignment.dueDate}</span>
                    <span className="text-indigo-400 font-semibold">{assignment.points} XP</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Main Editor & Details (8 cols) */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Assignment Description & Instructions Box */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs font-bold text-indigo-400">{activeAssignment.moduleName}</span>
                  <span className="text-slate-600">•</span>
                  <span className="text-xs text-slate-400 font-mono">{activeAssignment.difficulty} Level</span>
                </div>
                <h2 className="text-xl font-extrabold text-slate-100">{activeAssignment.title}</h2>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleFetchHint}
                  disabled={isLoadingHint}
                  className="px-3.5 py-1.5 text-xs font-bold bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 rounded-xl transition flex items-center gap-1.5"
                >
                  <HelpCircle className="w-4 h-4 text-amber-400" />
                  {isLoadingHint ? "Asking AI..." : "Get AI Hint"}
                </button>
              </div>
            </div>

            {/* AI Hint Drawer */}
            {hint && (
              <div className="p-4 rounded-2xl bg-amber-950/20 border border-amber-500/40 text-xs text-amber-200 space-y-1 animate-fadeIn">
                <div className="font-bold flex items-center gap-1.5 text-amber-300">
                  <Sparkles className="w-4 h-4" /> InCoder AI Tutor Hint:
                </div>
                <p className="leading-relaxed">{hint}</p>
              </div>
            )}

            <p className="text-sm text-slate-300 leading-relaxed">{activeAssignment.description}</p>

            {/* Step Instructions */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">Step Requirements:</h4>
              <ul className="space-y-1.5 text-xs text-slate-300">
                {activeAssignment.instructions.map((inst, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-indigo-400 font-bold font-mono">{idx + 1}.</span>
                    <span>{inst}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Rubrics breakdown */}
            <div className="pt-2 border-t border-slate-800/80">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Grading Rubric:</h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {activeAssignment.rubric.map((r, i) => (
                  <div key={i} className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 text-xs">
                    <div className="font-semibold text-slate-200">{r.criterion}</div>
                    <div className="text-[10px] text-indigo-400 font-mono mt-0.5">Weight: {r.weight}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Interactive Code Editor Workspace */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
            
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Terminal className="w-5 h-5 text-indigo-400" />
                <h3 className="font-bold text-slate-100 text-base">Code Submission Editor</h3>
                <span className="text-xs text-slate-500 font-mono">solution.ts</span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopyCode}
                  className="px-2.5 py-1 text-xs font-medium text-slate-400 hover:text-slate-200 bg-slate-800 rounded-lg transition flex items-center gap-1"
                  title="Copy code"
                >
                  <Copy className="w-3.5 h-3.5" />
                  {copied ? "Copied!" : "Copy"}
                </button>

                <button
                  onClick={handleResetCode}
                  className="px-2.5 py-1 text-xs font-medium text-slate-400 hover:text-slate-200 bg-slate-800 rounded-lg transition flex items-center gap-1"
                  title="Reset to Starter Code"
                >
                  <RotateCcw className="w-3.5 h-3.5" /> Reset Starter
                </button>
              </div>
            </div>

            {/* Textarea Code Editor */}
            <div className="relative rounded-2xl overflow-hidden border border-slate-800 bg-slate-950 font-mono text-sm">
              <textarea
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="// Write or paste your TypeScript code here..."
                rows={12}
                className="w-full p-4 bg-transparent text-emerald-400 focus:outline-none resize-y leading-relaxed font-mono selection:bg-indigo-600 selection:text-white"
                spellCheck={false}
              />
            </div>

            {/* Drag and Drop File Upload Option */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 rounded-2xl bg-slate-950/60 border border-dashed border-slate-800">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                  <UploadCloud className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-200">
                    {uploadedFileName ? `Attached: ${uploadedFileName}` : "Upload Code / Solution File (.ts, .js)"}
                  </div>
                  <p className="text-[11px] text-slate-400">Drag & drop or browse your local file system</p>
                </div>
              </div>

              <label className="px-4 py-2 text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl cursor-pointer border border-slate-700 transition">
                Browse File
                <input type="file" accept=".ts,.js,.json,.txt" onChange={handleFileUpload} className="hidden" />
              </label>
            </div>

            {/* Student Notes Input */}
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">
                Submission Notes / Developer Log (Optional)
              </label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g. Tested edge cases with null input arrays, passes all specs..."
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
              />
            </div>

            {/* Submit CTA Button */}
            <div className="pt-2">
              <button
                onClick={handleSubmitAndEvaluate}
                disabled={isEvaluating || !code.trim()}
                className={`w-full py-3.5 px-6 rounded-2xl font-extrabold text-sm text-white shadow-xl flex items-center justify-center gap-2 transition ${
                  isEvaluating
                    ? "bg-slate-800 cursor-not-allowed text-slate-400"
                    : "bg-gradient-to-r from-indigo-600 via-indigo-500 to-cyan-500 hover:from-indigo-500 hover:to-cyan-400 shadow-indigo-600/30"
                }`}
              >
                {isEvaluating ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin text-indigo-400" />
                    Running AI Evaluation & Test Suite...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5" />
                    Submit Code & Run AI Evaluation
                  </>
                )}
              </button>
            </div>

          </div>

          {/* AI Evaluation Results Card */}
          {evaluationResult && (
            <div className="bg-slate-900/90 border border-emerald-500/40 rounded-3xl p-6 shadow-2xl space-y-5 animate-fadeIn">
              
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
                <div>
                  <span className="px-2.5 py-0.5 text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-full flex items-center gap-1 w-fit mb-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Evaluation Completed
                  </span>
                  <h3 className="text-xl font-extrabold text-slate-100">Automated Grade Feedback</h3>
                  <p className="text-xs text-slate-400">Submitted at {evaluationResult.submittedAt}</p>
                </div>

                <div className="flex items-center gap-3 bg-slate-950 p-3 rounded-2xl border border-slate-800">
                  <div className="text-center pr-3 border-r border-slate-800">
                    <div className="text-2xl font-black text-amber-400">{evaluationResult.score}/100</div>
                    <div className="text-[10px] text-slate-400 uppercase font-bold">Score</div>
                  </div>
                  <div className="text-center pl-2">
                    <div className="text-2xl font-black text-emerald-400">{evaluationResult.gradeLetter}</div>
                    <div className="text-[10px] text-slate-400 uppercase font-bold">Grade</div>
                  </div>
                </div>
              </div>

              {/* Summary */}
              <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 text-xs text-slate-300 leading-relaxed">
                <strong className="text-indigo-400 font-semibold block mb-1">Instructor Executive Summary:</strong>
                {evaluationResult.summary}
              </div>

              {/* Automated Test Case Results Matrix */}
              {evaluationResult.testCases && evaluationResult.testCases.length > 0 && (
                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">Automated Test Case Suite:</h4>
                  <div className="space-y-2">
                    {evaluationResult.testCases.map((tc, idx) => (
                      <div
                        key={idx}
                        className={`p-3 rounded-xl border flex items-start gap-3 text-xs ${
                          tc.passed
                            ? "bg-emerald-950/20 border-emerald-500/30 text-emerald-200"
                            : "bg-rose-950/20 border-rose-500/30 text-rose-200"
                        }`}
                      >
                        {tc.passed ? (
                          <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                        ) : (
                          <X className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                        )}
                        <div>
                          <div className="font-bold text-slate-200">{tc.name}</div>
                          <p className="text-[11px] text-slate-400 mt-0.5">{tc.details}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Strengths & Recommendations Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {evaluationResult.strengths && evaluationResult.strengths.length > 0 && (
                  <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-2">
                    <h5 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1">
                      <Award className="w-4 h-4" /> Code Strengths
                    </h5>
                    <ul className="space-y-1 text-xs text-slate-300 list-disc list-inside">
                      {evaluationResult.strengths.map((s, i) => (
                        <li key={i}>{s}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {evaluationResult.areasForImprovement && evaluationResult.areasForImprovement.length > 0 && (
                  <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-2">
                    <h5 className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1">
                      <AlertCircle className="w-4 h-4" /> Actionable Improvements
                    </h5>
                    <ul className="space-y-1 text-xs text-slate-300 list-disc list-inside">
                      {evaluationResult.areasForImprovement.map((imp, i) => (
                        <li key={i}>{imp}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              {/* Code Refactoring Suggestion Snippet */}
              {evaluationResult.codeSuggestions && (
                <div className="space-y-2">
                  <h5 className="text-xs font-bold text-cyan-400 uppercase tracking-wider">Suggested Refactored Pattern:</h5>
                  <pre className="p-4 rounded-2xl bg-slate-950 border border-slate-800 font-mono text-xs text-cyan-300 overflow-x-auto">
                    {evaluationResult.codeSuggestions}
                  </pre>
                </div>
              )}

            </div>
          )}

        </div>

      </div>

    </div>
  );
};
