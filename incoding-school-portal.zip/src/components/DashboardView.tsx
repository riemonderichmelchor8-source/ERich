import React from "react";
import { 
  CheckCircle2, 
  Clock, 
  Sparkles, 
  TrendingUp, 
  Award, 
  ArrowRight, 
  BookOpen, 
  Bot, 
  Code2, 
  CircleDot,
  Calendar,
  Layers,
  ChevronRight
} from "lucide-react";
import { StudentProfile, Assignment, OnboardingTask } from "../types";

interface DashboardViewProps {
  profile: StudentProfile;
  assignments: Assignment[];
  onboardingTasks: OnboardingTask[];
  setOnboardingTasks: React.Dispatch<React.SetStateAction<OnboardingTask[]>>;
  setActiveTab: (tab: string) => void;
  setSelectedAssignmentId: (id: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  profile,
  assignments,
  onboardingTasks,
  setOnboardingTasks,
  setActiveTab,
  setSelectedAssignmentId
}) => {
  // Real-time progress calculations
  const completedTaskCount = onboardingTasks.filter((t) => t.completed).length;
  const taskProgressPercent = Math.round((completedTaskCount / onboardingTasks.length) * 100);

  const gradedAssignments = assignments.filter((a) => a.status === "graded");
  const submittedAssignments = assignments.filter((a) => a.status === "submitted" || a.status === "graded");
  const assignmentProgressPercent = Math.round((submittedAssignments.length / assignments.length) * 100);

  const averageScore = gradedAssignments.length > 0
    ? Math.round(gradedAssignments.reduce((acc, cur) => acc + (cur.submission?.score || 0), 0) / gradedAssignments.length)
    : 100;

  const toggleTask = (taskId: string) => {
    setOnboardingTasks((prev) =>
      prev.map((t) => (t.id === taskId ? { ...t, completed: !t.completed } : t))
    );
  };

  return (
    <div className="space-y-8 pb-12">
      
      {/* Welcome Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-indigo-500/30 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 -mt-8 -mr-8 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-1/3 -mb-8 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 text-xs font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 rounded-full flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" /> Welcome Back, InCoder!
              </span>
              <span className="text-xs text-slate-400 font-mono">ID: {profile.studentId}</span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
              {profile.name}
            </h1>
            <p className="text-sm text-slate-300 max-w-xl">
              Track: <strong className="text-cyan-300">{profile.track}</strong> • {profile.cohort}
            </p>
          </div>

          <div className="flex items-center gap-3 bg-slate-950/70 p-4 rounded-2xl border border-slate-800 shadow-inner shrink-0">
            <div className="text-center pr-3 border-r border-slate-800">
              <div className="text-2xl font-black text-indigo-400">{profile.level}</div>
              <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Level</div>
            </div>
            <div className="text-center px-3 border-r border-slate-800">
              <div className="text-2xl font-black text-emerald-400">{profile.totalPoints}</div>
              <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">XP Points</div>
            </div>
            <div className="text-center pl-3">
              <div className="text-2xl font-black text-amber-400">{averageScore}%</div>
              <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">GPA Average</div>
            </div>
          </div>
        </div>
      </div>

      {/* Real-time Progress Tracking Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        
        {/* Card 1: Onboarding Tasks */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col justify-between space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Onboarding Checklist</span>
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <div className="flex items-baseline justify-between mb-2">
              <span className="text-3xl font-black text-slate-100">{taskProgressPercent}%</span>
              <span className="text-xs text-slate-400 font-medium">{completedTaskCount} of {onboardingTasks.length} tasks</span>
            </div>
            <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
              <div
                className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full transition-all duration-700"
                style={{ width: `${taskProgressPercent}%` }}
              ></div>
            </div>
          </div>
          <p className="text-[11px] text-slate-400">Complete tasks to earn orientation XP badges.</p>
        </div>

        {/* Card 2: Assignments Progress */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col justify-between space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Assignments Submitted</span>
            <BookOpen className="w-5 h-5 text-indigo-400" />
          </div>
          <div>
            <div className="flex items-baseline justify-between mb-2">
              <span className="text-3xl font-black text-slate-100">{assignmentProgressPercent}%</span>
              <span className="text-xs text-slate-400 font-medium">{submittedAssignments.length} of {assignments.length} complete</span>
            </div>
            <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
              <div
                className="bg-gradient-to-r from-indigo-500 to-cyan-400 h-full rounded-full transition-all duration-700"
                style={{ width: `${assignmentProgressPercent}%` }}
              ></div>
            </div>
          </div>
          <p className="text-[11px] text-slate-400">Submit code solutions for automated AI evaluation.</p>
        </div>

        {/* Card 3: Grade Performance */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col justify-between space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Average Evaluation</span>
            <TrendingUp className="w-5 h-5 text-amber-400" />
          </div>
          <div>
            <div className="flex items-baseline justify-between mb-2">
              <span className="text-3xl font-black text-amber-400">{averageScore}/100</span>
              <span className="px-2 py-0.5 text-xs font-bold bg-amber-500/20 text-amber-300 rounded">Grade: A</span>
            </div>
            <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
              <div
                className="bg-amber-400 h-full rounded-full transition-all duration-700"
                style={{ width: `${averageScore}%` }}
              ></div>
            </div>
          </div>
          <p className="text-[11px] text-slate-400">Based on automated rubric & test suite runs.</p>
        </div>

        {/* Card 4: Unlocked Badges */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col justify-between space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Cohort Badges</span>
            <Award className="w-5 h-5 text-cyan-400" />
          </div>
          <div>
            <div className="flex items-center gap-2 mb-2">
              {profile.badges.map((b) => (
                <span
                  key={b.id}
                  title={b.name}
                  className={`text-xl p-1.5 rounded-lg border ${
                    b.isUnlocked
                      ? "bg-slate-800 border-indigo-500/40"
                      : "bg-slate-950 border-slate-800 opacity-40 grayscale"
                  }`}
                >
                  {b.icon}
                </span>
              ))}
            </div>
            <div className="text-xs text-slate-300 font-medium">
              {profile.badges.filter((b) => b.isUnlocked).length} of {profile.badges.length} Badges Unlocked
            </div>
          </div>
          <p className="text-[11px] text-slate-400">Earn badges through streak activity & coding.</p>
        </div>

      </div>

      {/* Main Content Split Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Column (2 cols): Onboarding Checklist + Active Assignments */}
        <div className="lg:col-span-2 space-y-8">
          
          {/* Real-time Interactive Onboarding Milestone Checklist */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-5">
              <div>
                <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                  <Layers className="w-5 h-5 text-indigo-400" /> Real-time Onboarding Tracker
                </h2>
                <p className="text-xs text-slate-400">Check off items to instantly update your student progress</p>
              </div>
              <span className="px-3 py-1 text-xs font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 rounded-full">
                {completedTaskCount}/{onboardingTasks.length} Completed
              </span>
            </div>

            <div className="space-y-3">
              {onboardingTasks.map((task) => (
                <div
                  key={task.id}
                  onClick={() => toggleTask(task.id)}
                  className={`flex items-start gap-4 p-3.5 rounded-2xl border transition cursor-pointer ${
                    task.completed
                      ? "bg-emerald-950/20 border-emerald-500/30 text-slate-300"
                      : "bg-slate-950/60 border-slate-800/80 text-slate-200 hover:border-slate-700"
                  }`}
                >
                  <button
                    className={`mt-0.5 w-5 h-5 rounded-md flex items-center justify-center transition ${
                      task.completed
                        ? "bg-emerald-500 text-slate-950"
                        : "border-2 border-slate-600 hover:border-indigo-400"
                    }`}
                  >
                    {task.completed && <CheckCircle2 className="w-4 h-4 stroke-[3]" />}
                  </button>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <h4 className={`text-sm font-semibold ${task.completed ? "line-through text-slate-400" : "text-slate-100"}`}>
                        {task.title}
                      </h4>
                      <span className="text-[10px] font-bold text-indigo-400 bg-indigo-500/10 border border-indigo-500/20 px-2 py-0.5 rounded">
                        +{task.points} XP
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">{task.description}</p>
                    <div className="flex items-center gap-3 mt-2 text-[11px] text-slate-500">
                      <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {task.estimatedTime}</span>
                      <span>•</span>
                      <span className="text-slate-400 font-mono">{task.category}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Active Assignments Hub */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-5">
              <div>
                <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                  <Code2 className="w-5 h-5 text-cyan-400" /> Active Coding Assignments
                </h2>
                <p className="text-xs text-slate-400">Submit solutions for automated test suite grading</p>
              </div>
              <button
                onClick={() => setActiveTab("assignments")}
                className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
              >
                View All <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-4">
              {assignments.map((assignment) => {
                const isSubmitted = assignment.status === "submitted" || assignment.status === "graded";
                return (
                  <div
                    key={assignment.id}
                    className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 hover:border-slate-700 transition space-y-3"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-400 bg-cyan-500/10 border border-cyan-500/20 px-2 py-0.5 rounded">
                            {assignment.moduleName}
                          </span>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                            assignment.difficulty === "Beginner"
                              ? "bg-emerald-500/20 text-emerald-300"
                              : "bg-amber-500/20 text-amber-300"
                          }`}>
                            {assignment.difficulty}
                          </span>
                        </div>
                        <h3 className="font-bold text-slate-100 text-base mt-1">{assignment.title}</h3>
                      </div>

                      <div className="flex items-center gap-2">
                        {isSubmitted ? (
                          <span className="px-3 py-1 text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-full flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Graded ({assignment.submission?.score}/100)
                          </span>
                        ) : (
                          <button
                            onClick={() => {
                              setSelectedAssignmentId(assignment.id);
                              setActiveTab("assignments");
                            }}
                            className="px-4 py-1.5 text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl shadow-md transition flex items-center gap-1.5"
                          >
                            Submit Code <ArrowRight className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>

                    <p className="text-xs text-slate-300 line-clamp-2">{assignment.description}</p>

                    <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800/60">
                      <span className="flex items-center gap-1"><Calendar className="w-3 h-3 text-indigo-400" /> Due: {assignment.dueDate}</span>
                      <span className="font-mono font-semibold text-indigo-300">{assignment.points} Points</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

        </div>

        {/* Right Column (1 col): AI Tutor Quick Launcher + Cohort Feed */}
        <div className="space-y-8">
          
          {/* AI Code Tutor Widget */}
          <div className="bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 border border-indigo-500/40 rounded-3xl p-6 shadow-xl relative overflow-hidden">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center">
                <Bot className="w-6 h-6 text-indigo-400 animate-pulse" />
              </div>
              <div>
                <h3 className="font-bold text-slate-100 text-base">InCoder AI Assistant</h3>
                <p className="text-xs text-cyan-300 font-medium">24/7 Gemini 3.6 Flash TA</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 mb-4 leading-relaxed">
              Need help debugging an error or clarifying an assignment requirement? Ask InCoder AI for step-by-step guidance.
            </p>

            <button
              onClick={() => setActiveTab("ai-tutor")}
              className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition"
            >
              <Bot className="w-4 h-4" /> Launch AI Tutor Workspace
            </button>
          </div>

          {/* Incoming Cohort Quick Activity */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-slate-100 text-sm flex items-center gap-2">
                <CircleDot className="w-4 h-4 text-emerald-400" /> Cohort Live Pulse
              </h3>
              <span className="text-[10px] text-slate-400 font-mono">Fall 2026</span>
            </div>

            <div className="space-y-3">
              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs space-y-1">
                <div className="flex items-center justify-between font-medium text-slate-200">
                  <span>Sarah Chen</span>
                  <span className="text-[10px] text-emerald-400">Online</span>
                </div>
                <p className="text-slate-400 text-[11px]">Completed Module 1 with 98% score</p>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs space-y-1">
                <div className="flex items-center justify-between font-medium text-slate-200">
                  <span>Alex Mercer (TA)</span>
                  <span className="text-[10px] text-indigo-400">Answering Forum</span>
                </div>
                <p className="text-slate-400 text-[11px]">Posted answer in #Homework-Help</p>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs space-y-1">
                <div className="flex items-center justify-between font-medium text-slate-200">
                  <span>David K.</span>
                  <span className="text-[10px] text-amber-400">Coding</span>
                </div>
                <p className="text-slate-400 text-[11px]">Working on Array Algorithms task</p>
              </div>
            </div>

            <button
              onClick={() => setActiveTab("forum")}
              className="w-full py-2 text-xs font-semibold text-indigo-400 hover:text-indigo-300 border border-slate-800 hover:border-slate-700 rounded-xl transition text-center"
            >
              Join Discussion Forum
            </button>
          </div>

        </div>

      </div>

    </div>
  );
};
