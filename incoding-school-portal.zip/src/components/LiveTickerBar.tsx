import React, { useState, useEffect } from "react";
import { Radio, Zap, Sparkles, MessageSquare, Award } from "lucide-react";

const liveTickerEvents = [
  { icon: Zap, text: "Sarah Chen submitted 'Orientation Setup' — Score: 98/100 (A+)", color: "text-amber-400" },
  { icon: MessageSquare, text: "New discussion in #Homework-Help: 'TypeScript Optional Chaining'", color: "text-indigo-400" },
  { icon: Award, text: "David K. unlocked 'Early Bird' Student Badge (+50 XP)", color: "text-emerald-400" },
  { icon: Sparkles, text: "InCoder AI Assistant updated with Gemini 3.6 Flash model for fast code reviews", color: "text-cyan-400" },
  { icon: Zap, text: "Jordan Rivera completed Onboarding Milestone: 'Verify Git & GitHub SSH'", color: "text-amber-400" }
];

export const LiveTickerBar: React.FC = () => {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setIndex((prev) => (prev + 1) % liveTickerEvents.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const current = liveTickerEvents[index];
  const Icon = current.icon;

  return (
    <div className="bg-slate-950 border-b border-slate-800/80 py-2 px-4 text-xs">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        
        <div className="flex items-center gap-2.5 overflow-hidden">
          <span className="flex items-center gap-1.5 font-bold uppercase tracking-wider text-[10px] bg-rose-500/10 text-rose-400 border border-rose-500/30 px-2 py-0.5 rounded-full shrink-0">
            <Radio className="w-3 h-3 animate-pulse" /> Live Stream
          </span>
          <div className="flex items-center gap-2 text-slate-300 font-medium truncate transition-all duration-500">
            <Icon className={`w-3.5 h-3.5 shrink-0 ${current.color}`} />
            <span className="truncate">{current.text}</span>
          </div>
        </div>

        <div className="hidden sm:flex items-center gap-3 text-slate-400 shrink-0 font-mono text-[11px]">
          <span>Cohort: Fall 2026</span>
          <span className="text-slate-600">•</span>
          <span>Semester: Onboarding Phase</span>
        </div>

      </div>
    </div>
  );
};
