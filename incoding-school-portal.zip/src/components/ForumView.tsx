import React, { useState } from "react";
import { 
  MessagesSquare, 
  Search, 
  Plus, 
  ThumbsUp, 
  MessageCircle, 
  CheckCircle2, 
  Tag, 
  Code2, 
  Eye, 
  Sparkles, 
  Send, 
  User, 
  X,
  Filter
} from "lucide-react";
import { ForumPost, ForumReply } from "../types";

interface ForumViewProps {
  posts: ForumPost[];
  setPosts: React.Dispatch<React.SetStateAction<ForumPost[]>>;
  onPostCreated: () => void;
}

export const ForumView: React.FC<ForumViewProps> = ({ posts, setPosts, onPostCreated }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedPostId, setSelectedPostId] = useState<string | null>(posts[0]?.id || null);
  
  // New Post Form Modal State
  const [showNewPostModal, setShowNewPostModal] = useState<boolean>(false);
  const [newTitle, setNewTitle] = useState<string>("");
  const [newCategory, setNewCategory] = useState<"General" | "Homework Help" | "Show & Tell" | "Meetup" | "Career">("Homework Help");
  const [newTags, setNewTags] = useState<string>("TypeScript, React");
  const [newContent, setNewContent] = useState<string>("");
  const [newCodeSnippet, setNewCodeSnippet] = useState<string>("");

  // Reply Form State
  const [replyText, setReplyText] = useState<string>("");
  const [replyCode, setReplyCode] = useState<string>("");

  const categories = ["All", "General", "Homework Help", "Show & Tell", "Meetup", "Career"];

  const activePost = posts.find((p) => p.id === selectedPostId) || posts[0];

  // Upvote Post
  const handleToggleUpvote = (postId: string) => {
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id === postId) {
          const userUpvoted = !p.userUpvoted;
          return {
            ...p,
            userUpvoted,
            upvotes: userUpvoted ? p.upvotes + 1 : p.upvotes - 1
          };
        }
        return p;
      })
    );
  };

  // Upvote Reply
  const handleToggleReplyUpvote = (replyId: string) => {
    if (!activePost) return;
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id === activePost.id) {
          return {
            ...p,
            replies: p.replies.map((r) => {
              if (r.id === replyId) {
                const userUpvoted = !r.userUpvoted;
                return {
                  ...r,
                  userUpvoted,
                  upvotes: userUpvoted ? r.upvotes + 1 : r.upvotes - 1
                };
              }
              return r;
            })
          };
        }
        return p;
      })
    );
  };

  // Mark Reply as Verified Solution
  const handleMarkSolution = (replyId: string) => {
    if (!activePost) return;
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id === activePost.id) {
          return {
            ...p,
            isSolved: true,
            replies: p.replies.map((r) => ({
              ...r,
              isSolution: r.id === replyId
            }))
          };
        }
        return p;
      })
    );
  };

  // Submit Reply
  const handleSubmitReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim() || !activePost) return;

    const newReply: ForumReply = {
      id: "rep-" + Date.now(),
      authorName: "Jordan Rivera",
      authorAvatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150",
      authorRole: "Student",
      content: replyText,
      codeSnippet: replyCode || undefined,
      createdAt: "Just now",
      upvotes: 1
    };

    setPosts((prev) =>
      prev.map((p) => (p.id === activePost.id ? { ...p, replies: [...p.replies, newReply] } : p))
    );

    setReplyText("");
    setReplyCode("");
  };

  // Create New Post
  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newContent.trim()) return;

    const createdPost: ForumPost = {
      id: "post-" + Date.now(),
      authorName: "Jordan Rivera",
      authorAvatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150",
      authorRole: "Student",
      title: newTitle,
      category: newCategory,
      tags: newTags.split(",").map((t) => t.trim()).filter(Boolean),
      content: newContent,
      codeSnippet: newCodeSnippet || undefined,
      createdAt: "Just now",
      upvotes: 1,
      views: 1,
      isSolved: false,
      replies: []
    };

    setPosts([createdPost, ...posts]);
    setSelectedPostId(createdPost.id);
    setShowNewPostModal(false);

    // Reset form
    setNewTitle("");
    setNewContent("");
    setNewCodeSnippet("");

    onPostCreated();
  };

  const filteredPosts = posts.filter((p) => {
    const matchesCategory = selectedCategory === "All" || p.category === selectedCategory;
    const matchesSearch =
      p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-8 pb-12">
      
      {/* Forum Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 text-xs font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 rounded-full flex items-center gap-1">
              <MessagesSquare className="w-3.5 h-3.5" /> Incoming Cohort Forum
            </span>
          </div>
          <h1 className="text-2xl font-extrabold text-slate-100">Discussion & Homework Help</h1>
          <p className="text-xs text-slate-400">Ask questions, share code snippets, and collaborate with peers and TAs</p>
        </div>

        <button
          onClick={() => setShowNewPostModal(true)}
          className="px-5 py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs shadow-lg shadow-indigo-600/30 flex items-center gap-2 transition self-start md:self-auto"
        >
          <Plus className="w-4 h-4 stroke-[3]" /> Start Discussion Topic
        </button>
      </div>

      {/* Category Pills & Search Bar */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        
        {/* Category Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto pb-1">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition ${
                selectedCategory === cat
                  ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                  : "bg-slate-900/80 text-slate-400 hover:text-slate-200 border border-slate-800"
              }`}
            >
              {cat === "All" ? "All Topics" : `#${cat}`}
            </button>
          ))}
        </div>

        {/* Search Input */}
        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search discussions & tags..."
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
          />
        </div>

      </div>

      {/* Forum Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Posts List Column (5 cols) */}
        <div className="lg:col-span-5 space-y-3">
          {filteredPosts.length === 0 ? (
            <div className="p-8 text-center bg-slate-900/60 border border-slate-800 rounded-3xl text-xs text-slate-400">
              No topics found matching your criteria. Be the first to ask!
            </div>
          ) : (
            filteredPosts.map((post) => {
              const isSelected = activePost?.id === post.id;
              return (
                <div
                  key={post.id}
                  onClick={() => setSelectedPostId(post.id)}
                  className={`p-4 rounded-2xl border transition cursor-pointer space-y-2 ${
                    isSelected
                      ? "bg-indigo-950/40 border-indigo-500/80 shadow-lg shadow-indigo-950/50"
                      : "bg-slate-900/80 border-slate-800 hover:border-slate-700"
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[10px] font-bold text-indigo-400 bg-indigo-500/10 border border-indigo-500/20 px-2 py-0.5 rounded">
                      #{post.category}
                    </span>
                    {post.isSolved && (
                      <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Solved
                      </span>
                    )}
                  </div>

                  <h3 className="font-bold text-slate-100 text-sm leading-snug">{post.title}</h3>
                  <p className="text-xs text-slate-400 line-clamp-2">{post.content}</p>

                  <div className="flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-800/60">
                    <div className="flex items-center gap-1.5">
                      <img src={post.authorAvatar} alt={post.authorName} className="w-4 h-4 rounded-full object-cover" />
                      <span>{post.authorName}</span>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="flex items-center gap-1"><ThumbsUp className="w-3 h-3" /> {post.upvotes}</span>
                      <span className="flex items-center gap-1"><MessageCircle className="w-3 h-3" /> {post.replies.length}</span>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Post Detail Thread Column (7 cols) */}
        {activePost && (
          <div className="lg:col-span-7 space-y-6">
            
            {/* Active Thread Detail Box */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-5">
              
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div className="flex items-center gap-3">
                  <img src={activePost.authorAvatar} alt={activePost.authorName} className="w-10 h-10 rounded-full object-cover border border-indigo-500/40" />
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-slate-100 text-sm">{activePost.authorName}</h4>
                      <span className="px-2 py-0.5 text-[9px] font-bold bg-indigo-500/20 text-indigo-300 rounded uppercase">
                        {activePost.authorRole}
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-400">{activePost.createdAt}</span>
                  </div>
                </div>

                <button
                  onClick={() => handleToggleUpvote(activePost.id)}
                  className={`px-3.5 py-1.5 rounded-xl border text-xs font-bold transition flex items-center gap-1.5 ${
                    activePost.userUpvoted
                      ? "bg-indigo-600 text-white border-indigo-500 shadow-md"
                      : "bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700"
                  }`}
                >
                  <ThumbsUp className="w-3.5 h-3.5" />
                  <span>{activePost.upvotes} Upvotes</span>
                </button>
              </div>

              <div>
                <h2 className="text-xl font-extrabold text-slate-100 mb-2">{activePost.title}</h2>
                <div className="flex items-center gap-2 mb-4">
                  {activePost.tags.map((tag, i) => (
                    <span key={i} className="text-[10px] font-semibold text-cyan-300 bg-cyan-500/10 border border-cyan-500/20 px-2 py-0.5 rounded">
                      #{tag}
                    </span>
                  ))}
                </div>
                <p className="text-xs text-slate-300 leading-relaxed whitespace-pre-line">{activePost.content}</p>
              </div>

              {/* Code Snippet in Post */}
              {activePost.codeSnippet && (
                <div className="space-y-1">
                  <span className="text-[10px] font-mono text-slate-400 uppercase">Attached Code Snippet:</span>
                  <pre className="p-4 rounded-2xl bg-slate-950 border border-slate-800 font-mono text-xs text-emerald-400 overflow-x-auto">
                    {activePost.codeSnippet}
                  </pre>
                </div>
              )}

            </div>

            {/* Threaded Replies Section */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-5">
              <h3 className="font-bold text-slate-100 text-base flex items-center gap-2 border-b border-slate-800 pb-3">
                <MessageCircle className="w-5 h-5 text-indigo-400" /> Responses ({activePost.replies.length})
              </h3>

              <div className="space-y-4">
                {activePost.replies.length === 0 ? (
                  <p className="text-xs text-slate-400 text-center py-4">No replies yet. Be the first to offer guidance!</p>
                ) : (
                  activePost.replies.map((reply) => (
                    <div
                      key={reply.id}
                      className={`p-4 rounded-2xl border space-y-3 ${
                        reply.isSolution
                          ? "bg-emerald-950/20 border-emerald-500/50"
                          : "bg-slate-950/60 border-slate-800"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2.5">
                          <img src={reply.authorAvatar} alt={reply.authorName} className="w-8 h-8 rounded-full object-cover" />
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-slate-200 text-xs">{reply.authorName}</span>
                              <span className="px-1.5 py-0.5 text-[9px] font-bold bg-slate-800 text-indigo-300 rounded">
                                {reply.authorRole}
                              </span>
                            </div>
                            <span className="text-[10px] text-slate-500">{reply.createdAt}</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          {reply.isSolution ? (
                            <span className="px-2.5 py-1 text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 rounded-full flex items-center gap-1">
                              <CheckCircle2 className="w-3 h-3" /> Verified Solution
                            </span>
                          ) : (
                            <button
                              onClick={() => handleMarkSolution(reply.id)}
                              className="px-2 py-1 text-[10px] font-bold bg-slate-800 hover:bg-slate-700 text-slate-300 rounded transition"
                            >
                              Mark as Solution
                            </button>
                          )}

                          <button
                            onClick={() => handleToggleReplyUpvote(reply.id)}
                            className="px-2 py-1 text-[10px] font-bold bg-slate-800 hover:bg-slate-700 text-slate-300 rounded flex items-center gap-1 transition"
                          >
                            <ThumbsUp className="w-3 h-3" /> {reply.upvotes}
                          </button>
                        </div>
                      </div>

                      <p className="text-xs text-slate-300 leading-relaxed">{reply.content}</p>

                      {reply.codeSnippet && (
                        <pre className="p-3 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs text-cyan-300 overflow-x-auto">
                          {reply.codeSnippet}
                        </pre>
                      )}
                    </div>
                  ))
                )}
              </div>

              {/* Reply Form */}
              <form onSubmit={handleSubmitReply} className="pt-4 border-t border-slate-800 space-y-3">
                <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">Leave a Response:</h4>
                
                <textarea
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  placeholder="Share your answer, code suggestion, or explanation..."
                  rows={3}
                  className="w-full p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                />

                <textarea
                  value={replyCode}
                  onChange={(e) => setReplyCode(e.target.value)}
                  placeholder="// Optional code snippet format..."
                  rows={2}
                  className="w-full p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-emerald-400 focus:outline-none focus:border-indigo-500"
                />

                <div className="flex justify-end">
                  <button
                    type="submit"
                    disabled={!replyText.trim()}
                    className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md transition flex items-center gap-1.5"
                  >
                    <Send className="w-3.5 h-3.5" /> Post Response
                  </button>
                </div>
              </form>

            </div>

          </div>
        )}

      </div>

      {/* New Topic Modal */}
      {showNewPostModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-xl w-full p-6 shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-extrabold text-slate-100 text-lg flex items-center gap-2">
                <MessagesSquare className="w-5 h-5 text-indigo-400" /> Create Discussion Topic
              </h3>
              <button
                onClick={() => setShowNewPostModal(false)}
                className="p-1 rounded-lg bg-slate-800 text-slate-400 hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreatePost} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-300 mb-1">Topic Title</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. How to structure async handlers in Express?"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Category</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as any)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="Homework Help">Homework Help</option>
                    <option value="General">General</option>
                    <option value="Show & Tell">Show & Tell</option>
                    <option value="Meetup">Meetup</option>
                    <option value="Career">Career</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-300 mb-1">Tags (comma separated)</label>
                  <input
                    type="text"
                    value={newTags}
                    onChange={(e) => setNewTags(e.target.value)}
                    placeholder="TypeScript, Express"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">Detailed Question / Content</label>
                <textarea
                  required
                  rows={4}
                  value={newContent}
                  onChange={(e) => setNewContent(e.target.value)}
                  placeholder="Describe your question or discussion context..."
                  className="w-full p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">Optional Code Snippet</label>
                <textarea
                  rows={3}
                  value={newCodeSnippet}
                  onChange={(e) => setNewCodeSnippet(e.target.value)}
                  placeholder="// Paste relevant code snippet..."
                  className="w-full p-3.5 rounded-xl bg-slate-950 border border-slate-800 font-mono text-emerald-400 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowNewPostModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold shadow-md"
                >
                  Publish Topic
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
