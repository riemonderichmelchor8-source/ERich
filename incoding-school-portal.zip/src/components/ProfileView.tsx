import React, { useState } from "react";
import { 
  User, 
  Award, 
  Users, 
  History, 
  CheckCircle2, 
  Sparkles, 
  Mail, 
  Flame, 
  Search, 
  Edit3, 
  Save, 
  GraduationCap,
  Briefcase,
  Calendar
} from "lucide-react";
import { StudentProfile, CohortMember, Assignment } from "../types";

interface ProfileViewProps {
  profile: StudentProfile;
  setProfile: React.Dispatch<React.SetStateAction<StudentProfile>>;
  cohortMembers: CohortMember[];
  assignments: Assignment[];
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  profile,
  setProfile,
  cohortMembers,
  assignments
}) => {
  const [isEditingBio, setIsEditingBio] = useState<boolean>(false);
  const [bioInput, setBioInput] = useState<string>(profile.bio);
  const [searchMember, setSearchMember] = useState<string>("");

  const handleSaveBio = () => {
    setProfile((prev) => ({ ...prev, bio: bioInput }));
    setIsEditingBio(false);
  };

  const filteredMembers = cohortMembers.filter(
    (m) =>
      m.name.toLowerCase().includes(searchMember.toLowerCase()) ||
      m.track.toLowerCase().includes(searchMember.toLowerCase())
  );

  const gradedAssignments = assignments.filter((a) => a.status === "graded");

  return (
    <div className="space-y-8 pb-12">
      
      {/* Student ID Card Banner */}
      <div className="relative overflow-hidden bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-indigo-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          
          <div className="flex items-center gap-5">
            <img
              src={profile.avatar}
              alt={profile.name}
              className="w-20 h-20 rounded-2xl object-cover border-2 border-indigo-500/60 shadow-xl"
            />
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold text-cyan-300 bg-cyan-500/10 border border-cyan-500/20 px-2.5 py-0.5 rounded-full">
                  ID: {profile.studentId}
                </span>
                <span className="text-xs font-bold text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                  <Flame className="w-3.5 h-3.5" /> {profile.streakDays}d Streak
                </span>
              </div>
              <h1 className="text-2xl font-extrabold text-slate-100">{profile.name}</h1>
              <p className="text-xs text-slate-300 flex items-center gap-1">
                <Briefcase className="w-3.5 h-3.5 text-indigo-400" /> {profile.track} • {profile.cohort}
              </p>
            </div>
          </div>

          <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800 text-center min-w-[200px] space-y-2">
            <div className="text-xs text-slate-400 font-bold uppercase tracking-wider">Cohort Progress Level</div>
            <div className="text-3xl font-black text-indigo-400">Level {profile.level}</div>
            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div
                className="bg-gradient-to-r from-indigo-500 to-cyan-400 h-full rounded-full"
                style={{ width: `${(profile.xpCurrent / profile.xpNextLevel) * 100}%` }}
              ></div>
            </div>
            <div className="text-[10px] text-slate-400 font-mono">
              {profile.xpCurrent} / {profile.xpNextLevel} XP to Level {profile.level + 1}
            </div>
          </div>

        </div>

        {/* Bio Section */}
        <div className="mt-6 pt-6 border-t border-slate-800/80">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Student Bio:</span>
            {isEditingBio ? (
              <button onClick={handleSaveBio} className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                <Save className="w-3.5 h-3.5" /> Save Bio
              </button>
            ) : (
              <button onClick={() => setIsEditingBio(true)} className="text-xs font-bold text-indigo-400 flex items-center gap-1">
                <Edit3 className="w-3.5 h-3.5" /> Edit Bio
              </button>
            )}
          </div>

          {isEditingBio ? (
            <textarea
              value={bioInput}
              onChange={(e) => setBioInput(e.target.value)}
              rows={2}
              className="w-full p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
            />
          ) : (
            <p className="text-xs text-slate-300 leading-relaxed italic">"{profile.bio}"</p>
          )}
        </div>
      </div>

      {/* Badge Showcase Grid */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-400" /> Student Badges & Accomplishments
          </h2>
          <span className="text-xs text-slate-400 font-mono">
            {profile.badges.filter((b) => b.isUnlocked).length} / {profile.badges.length} Unlocked
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {profile.badges.map((badge) => (
            <div
              key={badge.id}
              className={`p-4 rounded-2xl border flex items-start gap-3 transition ${
                badge.isUnlocked
                  ? "bg-slate-950/80 border-indigo-500/40 text-slate-200"
                  : "bg-slate-950/30 border-slate-800/60 text-slate-500 opacity-60"
              }`}
            >
              <div className="text-3xl p-2 rounded-xl bg-slate-900 border border-slate-800 shrink-0">
                {badge.icon}
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <h4 className="font-bold text-sm text-slate-100">{badge.name}</h4>
                  {badge.isUnlocked && (
                    <span className="text-[9px] font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-1.5 py-0.2 rounded">
                      Unlocked
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-400 mt-1">{badge.description}</p>
                {badge.unlockedAt && (
                  <span className="text-[10px] text-slate-500 font-mono block mt-2">
                    Earned: {badge.unlockedAt}
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Cohort Classmate Directory */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div>
            <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <Users className="w-5 h-5 text-indigo-400" /> Incoming Cohort Directory
            </h2>
            <p className="text-xs text-slate-400">Classmates enrolled in Fall 2026 term</p>
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchMember}
              onChange={(e) => setSearchMember(e.target.value)}
              placeholder="Search classmates or track..."
              className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredMembers.map((member) => (
            <div
              key={member.id}
              className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 flex items-center gap-3"
            >
              <img
                src={member.avatar}
                alt={member.name}
                className="w-12 h-12 rounded-xl object-cover border border-slate-700 shrink-0"
              />

              <div className="min-w-0 flex-1 space-y-1">
                <div className="flex items-center justify-between gap-1">
                  <h4 className="font-bold text-slate-200 text-xs truncate">{member.name}</h4>
                  <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded capitalize ${
                    member.status === "online"
                      ? "bg-emerald-500/20 text-emerald-300"
                      : "bg-indigo-500/20 text-indigo-300"
                  }`}>
                    {member.status}
                  </span>
                </div>

                <p className="text-[11px] text-slate-400 truncate">{member.track}</p>

                <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mt-1">
                  <div
                    className="bg-indigo-500 h-full rounded-full"
                    style={{ width: `${member.progress}%` }}
                  ></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Submission History Breakdown Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
        <div className="border-b border-slate-800 pb-3">
          <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <History className="w-5 h-5 text-cyan-400" /> Past Assignment Evaluation Logs
          </h2>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/80 text-slate-400 uppercase font-mono text-[10px] border-b border-slate-800">
              <tr>
                <th className="p-3">Assignment</th>
                <th className="p-3">Track</th>
                <th className="p-3">Submitted At</th>
                <th className="p-3">Score</th>
                <th className="p-3">Grade</th>
                <th className="p-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {gradedAssignments.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-4 text-center text-slate-500">
                    No graded assignments yet. Submit code in the Assignments tab to generate logs.
                  </td>
                </tr>
              ) : (
                gradedAssignments.map((a) => (
                  <tr key={a.id} className="hover:bg-slate-950/40 transition">
                    <td className="p-3 font-semibold text-slate-100">{a.title}</td>
                    <td className="p-3 text-slate-400">{a.track}</td>
                    <td className="p-3 font-mono text-slate-400">{a.submission?.submittedAt}</td>
                    <td className="p-3 font-mono font-bold text-amber-400">{a.submission?.score}/100</td>
                    <td className="p-3 font-bold text-emerald-400">{a.submission?.gradeLetter}</td>
                    <td className="p-3">
                      <span className="px-2 py-0.5 text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded flex items-center gap-1 w-fit">
                        <CheckCircle2 className="w-3 h-3" /> Evaluated
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
